export const process = {
    env: {
        OPENAI_API_KEY: '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'
    }
}